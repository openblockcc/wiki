function getInterfaceTranslations () {
    return {
        "en": {
            "commonLed.name": "Common LED",
            "commonLed.description": "This is a demo with a common led."
        },
        "ru": {
            "commonLed.name": "Общий светодиод",
            "commonLed.description": "Это демо с общим светодиодом."
        },
        "zh-cn": {
            "commonLed.name": "普通 LED",
            "commonLed.description": "这是一个通用 LED 的演示。"
        },
        "zh-tw": {
            "commonLed.name": "普通 LED",
            "commonLed.description": "這是一個一般 LED 的演示。"
        }
    }
    ;
}

function registerBlocksMessages (Blockly) {
    Object.assign(Blockly.ScratchMsgs.locales["en"],
        {
            COMMONLED_CATEGORY: 'COMMONLED LED',
            COMMONLED_SETLEDSTATE: 'set pin %1 LED %2',
            COMMONLED_ON: 'on',
            COMMONLED_OFF: 'off'
        }
    );

    Object.assign(Blockly.ScratchMsgs.locales["ru"],
        {
            COMMONLED_CATEGORY: 'Общий светодиод',
            COMMONLED_SETLEDSTATE: 'Установить светодиод %1 на %2',
            COMMONLED_ON: 'Открыть',
            COMMONLED_OFF: 'закрытие'
        }
    );

    Object.assign(Blockly.ScratchMsgs.locales["zh-cn"],
        {
            COMMONLED_CATEGORY: '普通 LED',
            COMMONLED_SETLEDSTATE: '设置引脚 %1 LED 为 %2',
            COMMONLED_ON: '开',
            COMMONLED_OFF: '关'
        }
    );

    Object.assign(Blockly.ScratchMsgs.locales["zh-tw"],
        {
            COMMONLED_CATEGORY: '普通 LED',
            COMMONLED_SETLEDSTATE: '設定腳位 %1 LED 為 %2',
            COMMONLED_ON: '開',
            COMMONLED_OFF: '關'
        }
    );

    return Blockly;
}

if (typeof module !== 'undefined') {
    module.exports = {getInterfaceTranslations};
}
exports = registerBlocksMessages;
