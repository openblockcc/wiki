function registerBlocks (Blockly) {
    const color = '#A1C057';
    const secondaryColour = '#82A14C';

    Blockly.Blocks.commonLed_setLEDState = {
        init: function () {
            this.jsonInit({
                message0: Blockly.Msg.COMMONLED_SETLEDSTATE,
                args0: [
                    {
                        type: 'input_value',
                        name: 'pin'
                    },
                    {
                        type: 'field_dropdown',
                        name: 'state',
                        options: [
                            [Blockly.Msg.COMMONLED_ON, '1'],
                            [Blockly.Msg.COMMONLED_OFF, '0']]
                    }
                ],
                colour: color,
                secondaryColour: secondaryColour,
                extensions: ['shape_statement']
            });
        }
    };

    return Blockly;
}

exports = registerBlocks;
