function registerToolboxs () {
    return `
<category name="%{BKY_COMMONLED_CATEGORY}" id="COMMONLED_CATEGORY" colour="#A6D200" secondaryColour="#A1C057">
    <block type="commonLed_setLEDState" id="commonLed_setLEDState">
        <value name="pin">
            <shadow type="math_number">
                <field name="NUM">2</field>
            </shadow>
        </value>
    </block>
</category>`;
}

exports = registerToolboxs;
