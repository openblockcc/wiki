const commonLed = formatMessage => ({
    name: formatMessage({
        id: 'commonLed.name',
        default: 'Common LED',
        description: 'name of common led extension'
    }),
    extensionId: 'commonLed',
    version: '0.0.1',
    supportDevice: ['arduinoUno', 'arduinoNano', 'arduinoLeonardo', 'arduinoMega2560'],
    author: 'Your Name',
    iconURL: `assets/commonLed.png`,
    description: formatMessage({
        id: 'commonLed.description',
        default: 'This is a demo with a common led.',
        description: 'Description of common led'
    }),
    featured: true,
    blocks: 'blocks.js',
    generator: 'generator.js',
    toolbox: 'toolbox.js',
    translations: 'translations.js',
    official: true,
    tags: ['actuator'],
    helpLink: 'https://wiki.openblock.cc'
});

module.exports = commonLed;
