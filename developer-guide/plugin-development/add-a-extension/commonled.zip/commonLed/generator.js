function registerGenerators (Blockly) {
    Blockly.Arduino.commonLed_setLEDState = function (block) {
        const pin = Blockly.Arduino.valueToCode(block, 'pin', Blockly.Arduino.ORDER_ATOMIC);
        const state = this.getFieldValue('state');

        Blockly.Arduino.setups_[`commonLed_init${pin}`] = `pinMode(${pin}, OUTPUT);`;

        return `digitalWrite(${pin}, ${state});\n`;
    };

    return Blockly;
}

exports = registerGenerators;
