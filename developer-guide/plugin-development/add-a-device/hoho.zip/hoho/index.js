const hoho = formatMessage => ({
    name:  formatMessage({
        id: 'hoho.name',
        default: 'Hoho',
        description: 'Name for the hoho device'
    }),
    deviceId: 'hoho_arduinoUno',
    manufactor: 'Hoho inc.',
    learnMore: 'www.openblock.cc',
    iconURL: 'assets/hoho.png',
    description: formatMessage({
        id: 'hoho.description',
        default: 'This is a device demo.',
        description: 'Description for the hoho device'
    }),
    disabled: false,
    bluetoothRequired: false,
    serialportRequired: true,
    defaultBaudRate: '9600',
    pnpidList: [
        'USB\\VID_10C4&PID_EA60', // CP2102
        'USB\\VID_1A86&PID_7523' // CH340
    ],
    internetConnectionRequired: false,
    launchPeripheralConnectionFlow: true,
    useAutoScan: false,
    connectionIconURL: 'assets/hoho-illustration.svg',
    connectionSmallIconURL: 'assets/hoho-small.svg',
    programMode: ['realtime', 'upload'],
    programLanguage: ['block', 'cpp'],
    tags: ['kit'],
    deviceExtensionsCompatible: 'arduinoUno',
    helpLink: 'wiki.openblock.cc'
});

module.exports = hoho;
