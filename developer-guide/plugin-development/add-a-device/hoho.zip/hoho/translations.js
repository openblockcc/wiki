function getInterfaceTranslations () {
    return {
        "en": {
            "deviceDemo.name": "Hoho",
            "hoho.description": "This is a device demo."
        },
        "ru": {
            "deviceDemo.name": "Hoho",
            "hoho.description": "This is a device demo."
        },
        "zh-cn": {
            "deviceDemo.name": "THoho",
            "hoho.description": "This is a device demo."
        },
        "zh-tw": {
            "deviceDemo.name": "Hoho",
            "hoho.description": "This is a device demo."
        }
    };
}

if (typeof module !== 'undefined') {
    module.exports = {getInterfaceTranslations};
}
